
const NotFound = () => {  
  return (
    <div className="not-found">
      {/* <img src={Pichachu} alt="" /> */}
      <p>404 Page Not Found</p>
    </div>
  )
}

export default NotFound