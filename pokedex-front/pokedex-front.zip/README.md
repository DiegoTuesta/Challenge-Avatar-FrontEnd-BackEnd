# PokeDex

Aplicacion web realizada en React, Hooks, axios y css.

## Funciones
* Lista
* Paginación
* Muestra detalle pokemon

  [Link Deploy](https://challenge-avatar-diego-tuesta.netlify.app/)
